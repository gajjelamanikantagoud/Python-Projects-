import art
def add(n1, n2):
    return n1 + n2


def sub(n1, n2):
    return n1 - n2


def mul(n1, n2):
    return n1 * n2


def div(n1, n2):
    if n2 == 0:
        return None  # Signal error
    return n1 / n2


def op():
    print(art.logo)  # Use this if art.logo not a string
    dictionary = {"+": add, "-": sub, "*": mul, "/": div}

    while True:
        # Get first number with validation
        while True:
            try:
                n1 = float(input("Enter first number: "))
                break
            except ValueError:
                print("Invalid input. Please enter a numeric value.")

        while True:
            # Show available operations
            print("Available operations:")
            for key in dictionary:
                print(key)

            symbol = input("Pick an operation symbol: ")
            if symbol not in dictionary:
                print("Invalid symbol. Please choose a valid operation.")
                continue

            # Get second number with validation
            while True:
                try:
                    n2 = float(input("Enter second number: "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value.")

            result = dictionary[symbol](n1, n2)
            if result is None:
                print("Error: Division by zero is not allowed.")
                continue

            print(f"{n1} {symbol} {n2} = {result}")

            choice = input(
                "Type 'y' to continue calculating with the result, 'n' for a new calculation, or 's' to stop: ").lower()
            if choice == 'y':
                n1 = result
            elif choice == 'n':
                print("\n" * 3)  # Clear/space output for new calc
                break  # break inner loop; start new calculation from beginning
            elif choice == 's':
                print("Bye!")
                return
            else:
                print("Invalid choice. Exiting program.")
                return


if __name__ == "__main__":
    op()
