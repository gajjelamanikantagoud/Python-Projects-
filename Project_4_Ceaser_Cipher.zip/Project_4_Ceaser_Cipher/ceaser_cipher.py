import ceaser_ciper_ASCII_art

print(ceaser_ciper_ASCII_art.logo)

alphabet = [chr(i) for i in range(97, 123)]  # auto generates a-z
# you can also use full list of alphabets
# alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']

def caesar(original_text, shift_amount, encode_or_decode):
    if encode_or_decode == "decode":
        shift_amount *= -1
    shift_amount %= len(alphabet)

    output_text = ""
    for letter in original_text:
        if letter in alphabet:
            shifted_position = (alphabet.index(letter) + shift_amount) % len(alphabet)
            output_text += alphabet[shifted_position]
        else:
            output_text += letter
    print(f"Here is the {encode_or_decode}d result: {output_text}")


# Restartable loop
should_continue = True
while should_continue:
    direction = input("Type 'encode' to encrypt, type 'decode' to decrypt:\n").lower()
    if direction == 'encode' or direction=='decode':
        text = input("Type your message:\n").lower()
        shift = int(input("Type the shift number:\n"))
        caesar(original_text=text, shift_amount=shift, encode_or_decode=direction)

    else:
        print("enter valid input either 'encode' or 'decode'")

    restart = input("Do you want to go again? Type 'yes' or 'no':\n").lower()
    if restart != "yes":
        should_continue = False
        print("Goodbye 👋")
