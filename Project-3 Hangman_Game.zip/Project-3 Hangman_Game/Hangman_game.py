import random
import Hangman_wordsList
import Hangman_AsciiArt

lives = 6

chosen_word = random.choice(Hangman_wordsList.word_list)
#print(chosen_word)

placeholder = ""
word_length = len(chosen_word)
for position in range(word_length):
    placeholder += "_"
print("Word to guess: " + placeholder)

game_status = False
correct_guessed_letters = []

while not game_status:
    print(f"~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  {lives} LIVES LEFT  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n")
    guess = input("Guess a letter: ").lower()

    display = ""

    for letter in chosen_word:
        if letter == guess:
            display += letter
            correct_guessed_letters.append(guess)
        elif letter in correct_guessed_letters:
            display += letter
        else:
            display += "_"

    print("Word to guess: " + display)

    if guess not in chosen_word:
        print("You guessed d, that's not in the word. You lose a life.\n")
        lives -= 1

        if lives == 0:
            game_status = True

            print("~~~~~~~~~~~~~~~~~ YOU LOSE ~~~~~~~~~~~~~~~~~")

    if "_" not in display:
        game_status = True
        print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~  YOU WIN  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
# import from hangman_asciiart module to use here
    print(Hangman_AsciiArt.Phases[lives])
